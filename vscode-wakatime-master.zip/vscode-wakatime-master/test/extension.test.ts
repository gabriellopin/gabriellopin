import * as assert from 'assert';
import * as path from 'path';
import * as vscode from 'vscode';
import { WakaTime } from '../src/wakatime';

// Defines a Mocha test suite to group tests of similar kind together
suite("WakaTime Tests", () => {
	// Should be implemented after integration with CI/CD
});
